let x = 5;
x=10;
console.log(x);

const y = 3.17;

console.log(y);



function test1() {
    var test = 'hello'
}

{
   //var test = 'hello'
   const test='hello' 
}
console.log(test);


